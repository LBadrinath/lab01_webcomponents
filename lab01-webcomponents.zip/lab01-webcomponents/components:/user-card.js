class UserCard extends HTMLElement {
    static get observedAttributes() { 
      return ['name', 'role', 'img-src', 'data-about']; 
    }
  
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
    }
  
    connectedCallback() {
      this.render();
      this.addEventListeners();
    }
  
    attributeChangedCallback() {
      this.render();
      this.addEventListeners();
    }
  
    render() {
      const name = this.getAttribute('name') || 'Unknown Superstar';
      const role = this.getAttribute('role') || '';
      const img = this.getAttribute('img-src') || '';
      
      this.shadowRoot.innerHTML = `
        <style>
          .card {
            background: linear-gradient(135deg, #2a0a0a, #000000);
            padding: 12px;
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0,0,0,0.4);
            cursor: pointer;
            text-align: center;
            transition: transform 0.2s ease;
            border: 1px solid #cc0000;
          }
          .card:hover { 
            transform: scale(1.05); 
            box-shadow: 0 8px 25px rgba(204,0,0,0.6);
          }
          img { 
            width: 100%; 
            height: 180px; 
            object-fit: cover; 
            border-radius: 10px; 
            border: 2px solid gold;
          }
          h3 {
            margin: 8px 0 0; 
            color: white;
            font-size: 1.1rem;
          }
          p {
            margin: 0; 
            color: #ccc;
            font-style: italic;
          }
        </style>
        <div class="card">
          ${img ? `<img src="${img}" alt="${name}" loading="lazy">` : '<div style="height: 180px; background: #333; border-radius: 10px;"></div>'}
          <h3>${name}</h3>
          <p>${role}</p>
        </div>
      `;
    }
  
    addEventListeners() {
      const card = this.shadowRoot.querySelector('.card');
      if (card) {
        card.addEventListener('click', () => {
          this.dispatchEvent(new CustomEvent('select-user', {
            detail: { 
              name: this.getAttribute('name'),
              role: this.getAttribute('role'),
              imgSrc: this.getAttribute('img-src')
            },
            bubbles: true,
            composed: true
          }));
        });
      }
    }
  }
  
  customElements.define('user-card', UserCard);