class AppHeader extends HTMLElement {
    constructor(){
      super();
      this.attachShadow({mode: 'open'});
    }
  
    connectedCallback(){
      const title = this.getAttribute('title') || 'WWE Superstars';
      this.shadowRoot.innerHTML = `
        <style>
          header {
            background: linear-gradient(90deg, #cc0000, #000000);
            padding:18px;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.5);
            color:white;
            text-align:center;
            border: 2px solid gold;
          }
          h1{
            font-size:1.8rem;
            margin:0;
            text-transform: uppercase;
            letter-spacing: 2px;
          }
        </style>
        <header>
          <h1>${title}</h1>
        </header>
      `;
    }
  }
  customElements.define('app-header', AppHeader);