class UserDetails extends HTMLElement {
    constructor(){
      super();
      this.attachShadow({mode:'open'});
    }
  
    connectedCallback(){
      this._render("Select a superstar", "—", "", "");
    }
  
    showDetails(name, role, img, about){
      this._render(name, role, img, about);
    }
  
    _render(name, role, img, about){
      this.shadowRoot.innerHTML = `
        <style>
          .panel{
            display:flex;
            gap:20px;
            align-items:flex-start;
          }
          img{
            max-width:250px;
            border-radius:12px;
            box-shadow:0 6px 20px rgba(0,0,0,0.3);
          }
          .info{
            flex:1;
          }
          h2{margin:0;font-size:1.5rem;color:#222;}
          p{color:#444;font-size:1rem;line-height:1.4}
        </style>
        <div class="panel">
          ${img ? `<img src="${img}" alt="${name}">` : ''}
          <div class="info">
            <h2>${name}</h2>
            <p><em>${role}</em></p>
            <p>${about}</p>
          </div>
        </div>
      `;
    }
  }
  customElements.define('user-details', UserDetails);