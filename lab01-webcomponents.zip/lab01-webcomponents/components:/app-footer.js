class AppFooter extends HTMLElement {
    constructor(){
      super();
      this.attachShadow({mode:'open'});
    }
  
    connectedCallback(){
      const contact = this.getAttribute('contact') || 'info@wwe.com';
      this.shadowRoot.innerHTML = `
        <style>
          footer {
            text-align:center;
            color: #eee;
            font-size:0.95rem;
            padding:10px;
            border-top: 1px solid #cc0000;
          }
        </style>
        <footer>
          <p>Made for Lab 01 — WWE Universe Contact: ${contact}</p>
        </footer>
      `;
    }
  }
  customElements.define('app-footer', AppFooter);