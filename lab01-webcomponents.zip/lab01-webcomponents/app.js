// app.js - Complete application with all components

// Custom Elements Definitions
class AppHeader extends HTMLElement {
    constructor(){
      super();
      this.attachShadow({mode: 'open'});
    }
  
    connectedCallback(){
      const title = this.getAttribute('title') || 'WWE Superstars';
      this.shadowRoot.innerHTML = `
        <style>
          header {
            background: linear-gradient(90deg, #cc0000, #000000);
            padding: 18px;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.5);
            color: white;
            text-align: center;
            border: 2px solid gold;
          }
          h1 {
            font-size: 1.8rem;
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 2px;
          }
        </style>
        <header>
          <h1>${title}</h1>
        </header>
      `;
    }
  }
  
  class UserCard extends HTMLElement {
    static get observedAttributes() { return ['name','role','img-src']; }
    
    constructor(){
      super();
      this.attachShadow({mode:'open'});
    }
  
    connectedCallback(){ 
      this.render();
      this.addClickEvent();
    }
  
    attributeChangedCallback(){ 
      this.render();
      this.addClickEvent();
    }
  
    render(){
      const name = this.getAttribute('name') || 'Unknown Superstar';
      const role = this.getAttribute('role') || '';
      const img = this.getAttribute('img-src') || '';
      
      this.shadowRoot.innerHTML = `
        <style>
          .card {
            background: linear-gradient(135deg, #2a0a0a, #000000);
            padding: 12px;
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0,0,0,0.4);
            cursor: pointer;
            text-align: center;
            transition: transform 0.2s ease;
            border: 1px solid #cc0000;
          }
          .card:hover { 
            transform: scale(1.05); 
          }
          img { 
            width: 100%; 
            height: 180px; 
            object-fit: cover; 
            border-radius: 10px; 
          }
          h3 {
            margin: 8px 0 0; 
            color: white;
          }
          p {
            margin: 0; 
            color: #ccc;
          }
        </style>
        <div class="card">
          ${img ? `<img src="${img}" alt="${name}">` : '<div style="height: 180px; background: #333;"></div>'}
          <h3>${name}</h3>
          <p>${role}</p>
        </div>
      `;
    }
  
    addClickEvent() {
      const card = this.shadowRoot.querySelector('.card');
      if (card) {
        card.onclick = () => {
          this.dispatchEvent(new CustomEvent('select-user', {
            detail: { 
              name: this.getAttribute('name'),
              role: this.getAttribute('role'),
              imgSrc: this.getAttribute('img-src'),
              about: this.getAttribute('data-about')
            },
            bubbles: true
          }));
        };
      }
    }
  }
  
  class UserDetails extends HTMLElement {
    constructor(){
      super();
      this.attachShadow({mode:'open'});
    }
  
    connectedCallback(){
      this.render("Select a superstar", "—", "", "");
    }
  
    showDetails(name, role, img, about){
      this.render(name, role, img, about);
    }
  
    render(name, role, img, about){
      this.shadowRoot.innerHTML = `
        <style>
          .panel {
            display: flex;
            gap: 20px;
            align-items: flex-start;
          }
          img {
            max-width: 250px;
            border-radius: 12px;
          }
          .info {
            flex: 1;
          }
          h2 {
            margin: 0;
            color: #222;
          }
          p {
            color: #444;
          }
        </style>
        <div class="panel">
          ${img ? `<img src="${img}" alt="${name}">` : ''}
          <div class="info">
            <h2>${name}</h2>
            <p><em>${role}</em></p>
            <p>${about}</p>
          </div>
        </div>
      `;
    }
  }
  
  class AppFooter extends HTMLElement {
    constructor(){
      super();
      this.attachShadow({mode:'open'});
    }
  
    connectedCallback(){
      const contact = this.getAttribute('contact') || 'info@wwe.com';
      this.shadowRoot.innerHTML = `
        <style>
          footer {
            text-align: center;
            color: #eee;
            padding: 10px;
          }
        </style>
        <footer>
          <p>WWE Universe - Contact: ${contact}</p>
        </footer>
      `;
    }
  }
  
  // Register custom elements
  customElements.define('app-header', AppHeader);
  customElements.define('user-card', UserCard);
  customElements.define('user-details', UserDetails);
  customElements.define('app-footer', AppFooter);
  
  // Main Application Logic
  document.addEventListener('DOMContentLoaded', function() {
    const app = document.getElementById('app');
    
    try {
      // Clear loading message
      app.innerHTML = '';
  
      // Create header
      const header = document.createElement('app-header');
      header.setAttribute('title', '💪 WWE Superstars');
      app.appendChild(header);
  
      // Create main content area
      const main = document.createElement('main');
      main.style.display = 'grid';
      main.style.gridTemplateColumns = '320px 1fr';
      main.style.gap = '20px';
      main.style.margin = '20px 0';
  
      // Left column - Superstar list
      const leftColumn = document.createElement('div');
      leftColumn.innerHTML = '<div style="color: #ff0000; font-weight: bold; margin-bottom: 10px;">WWE Roster</div>';
      
      // WWE Superstars data (using placeholder images that should work)
      const superstars = [
        { 
          name: 'John Cena', 
          role: '16-time World Champion', 
          img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6SBFO_34s3mUw1zz2SuAVXn83OArtd8D9GQ&s',
          about: '🎤 John Cena is one of the most iconic superstars in WWE history, celebrated for his charisma, hard work, and ability to connect with fans. As a 16-time world champion, he became the face of the company for over a decade, inspiring millions with his “Never Give Up” motto. Beyond wrestling, Cena has found success in Hollywood films and is admired worldwide for his record-breaking contributions to the Make-A-Wish Foundation, making him a true role model both inside and outside the ring.'
        },
        { 
          name: 'The Rock', 
          role: 'People\'s Champion', 
          img: 'https://www.wwe.com/f/styles/talent_champion_lg/public/all/2024/03/The_Rock_PROFILE--927b15797eefad54a3bca4d2a15e4921.png', 
          about: '⏰ If you smell what The Rock is cooking! Most electrifying man in sports entertainment,The Rock, also known as Dwayne Johnson, is one of WWE’s most electrifying superstars, remembered for his unmatched charisma and powerful in-ring style. A 10-time world champion, he became “The People’s Champion” by entertaining millions with his iconic promos, catchphrases, and rivalries. Beyond wrestling, he rose to become one of Hollywood’s highest-paid actors, yet he remains a beloved WWE legend whose legacy continues to inspire fans worldwide..'
        },
        { 
          name: 'Stone Cold', 
          role: 'Texas Rattlesnake', 
          img: 'https://www.wwe.com/f/styles/talent_champion_lg/public/rd-talent/Profile/Stone_Cold_Steve_Austin_pro.png', 
          about: '🍺 Austin 3:16 says I just whipped your ass! The toughest S.O.B. in WWE history.Stone Cold Steve Austin is one of the most influential superstars in WWE history, credited with leading the company’s rise during the Attitude Era. Known as the “Texas Rattlesnake,” he became a fan favorite for his rebellious attitude, beer celebrations, and his famous catchphrase “Austin 3:16 says I just whooped your ass!”. A six-time WWE Champion, Austin’s fierce rivalries with Vince McMahon and The Rock defined an era of wrestling. His rebellious persona made him a cultural icon, and he is remembered as one of the greatest and most popular wrestlers of all time.'
        },
        { 
          name: 'Roman Reigns', 
          role: 'Tribal Chief', 
          img: 'https://www.wwe.com/f/styles/talent_champion_lg/public/all/2025/04/24-10-25_Square_Gallery360_Gallery360_3810_Profile--5104a0e6cf4b331f2d93d5a9b9662164.png', 
          about: '👆 Acknowledge Him! The Head of the Table and longest-reigning Universal Champion.Roman Reigns is one of the most dominant superstars in modern WWE history, often called the “Tribal Chief” and “Head of the Table.” A multiple-time world champion, he is known for his incredible strength, resilience, and leadership of The Bloodline faction alongside The Usos and Solo Sikoa. Since his return in 2020, Reigns has held one of the longest championship reigns in WWE history, establishing himself as the face of the company. His mix of power, charisma, and storytelling has made him a defining figure of the current era in professional wrestling.'
        }
      ];
  
      // Create superstar cards
      superstars.forEach(superstar => {
        const card = document.createElement('user-card');
        card.setAttribute('name', superstar.name);
        card.setAttribute('role', superstar.role);
        card.setAttribute('img-src', superstar.img);
        card.setAttribute('data-about', superstar.about);
        leftColumn.appendChild(card);
      });
  
      // Right column - Details panel
      const rightColumn = document.createElement('div');
      rightColumn.style.background = '#ffffff';
      rightColumn.style.padding = '18px';
      rightColumn.style.borderRadius = '12px';
      rightColumn.style.color = '#111';
      
      const details = document.createElement('user-details');
      details.setAttribute('name', 'Select a superstar');
      details.setAttribute('role', '—');
      rightColumn.appendChild(details);
  
      // Assemble main layout
      main.appendChild(leftColumn);
      main.appendChild(rightColumn);
      app.appendChild(main);
  
      // Create footer
      const footer = document.createElement('app-footer');
      footer.setAttribute('contact', 'wwe@universe.org');
      app.appendChild(footer);
  
      // Handle card selection
      app.addEventListener('select-user', function(event) {
        const { name, role, imgSrc, about } = event.detail;
        details.showDetails(name, role, imgSrc, about);
      });
  
      console.log('WWE Superstars app loaded successfully!');
  
    } catch (error) {
      console.error('Error loading app:', error);
      app.innerHTML = '<div style="color: red; text-align: center; padding: 50px;">Error loading application. Check console.</div>';
    }
  });